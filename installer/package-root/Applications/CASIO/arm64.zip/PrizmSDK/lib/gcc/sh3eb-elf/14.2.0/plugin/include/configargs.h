/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-14.2.0/./configure --target=sh3eb-elf --prefix=/Applications/CASIO/PrizmSDK --with-gmp=/opt/homebrew/Cellar/gmp/6.3.0 --with-mpfr=/opt/homebrew/Cellar/mpfr/4.2.1 --with-mpc=/opt/homebrew/Cellar/libmpc/1.3.1 --disable-nls --enable-languages=c,c++ --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
