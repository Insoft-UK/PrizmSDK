#ifndef __FXCG_DISPLAY_H
#define __FXCG_DISPLAY_H

#include <stdint.h>


#define LCD_WIDTH_PX 384
#define LCD_HEIGHT_PX 216

/* Set up for C function definitions, even when using C++ */
#ifdef __cplusplus
extern "C" {
#endif

#define SAF_BATTERY             0x0001
#define SAF_ALPHA_SHIFT         0x0002
#define SAF_SETUP_INPUT_OUTPUT  0x0004
#define SAF_SETUP_FRAC_RESULT   0x0008
#define SAF_SETUP_ANGLE         0x0010
#define SAF_SETUP_COMPLEX_MODE  0x0020
#define SAF_SETUP_DISPLAY       0x0040
#define SAF_TEXT                0x0100
#define SAF_GLYPH               0x0200

enum TextMode {
    TEXT_MODE_NORMAL    = 0,
    TEXT_MODE_INVERT    = 1
};

enum TextColor {
    TEXT_COLOR_BLACK    = 0,
    TEXT_COLOR_BLUE     = 1,
    TEXT_COLOR_GREEN    = 2,
    TEXT_COLOR_CYAN     = 3,
    TEXT_COLOR_RED      = 4,
    TEXT_COLOR_MAGENTA  = 5,
    TEXT_COLOR_YELLOW   = 6,
    TEXT_COLOR_WHITE    = 7
};

typedef uint16_t color_t;

typedef enum {
    ColorBlack = 0x0000,
    ColorBlue = 0x001F,
    ColorGreen = 0x07E0,
    ColorCyan = 0x07FF,
    ColorRed = 0xF800,
    ColorMagenta = 0xF81F,
    ColorYellow = 0xFFE0,
    ColorWhite = 0xFFFF,
    ColorGray = 0x8410,
    ColorBrown = 0xA145,
    ColorOrange = 0xFD20,


    ColorDarkBlue = 0x0011,
    ColorDarkGreen = 0x0320,
    ColorDarkCyan = 0x0451,
    ColorDarkRed = 0x8800,
    ColorDarkMagenta = 0x8811,

    ColorDarkGray = 0xAD55,
    ColorDarkOrange = 0xfc60,

 
    ColorLightBlue = 0xAEDC,
    ColorLightGreen = 0x9772,
    ColorLightCyan = 0xE7FF,
    ColorLightGray = 0xd69A,
    ColorLightYellow = 0xFFFC,

    ColorPink = 0xFE19,
    ColorPurple = 0x8010,
    ColorSilver = 0xC618,
} TColor;


typedef enum AreaMode {
    kAreaMode_BelowStatus                   = 1,
    kAreaMode_BetweenStatusAndFKeyLabels    = 2,
    kAreaMode_WholeVRAM                     = 3
} TAreaMode;

//MARK: - General Display Manipulating SYSCALLS
typedef struct BdispFillArea {
    int x1;
    int y1;
    int x2;
    int y2;
    uint8_t mode;
} TBdispFillArea;

typedef enum {
    FillAreaModeWhite     = 0,
    FillAreaModeColor      = 1
} TFillAreaMode;

typedef enum {
    FillAreaTargetVRAM     = 0x01,
    FillAreaTargetDD       = 0x02
} TFillAreaTarget;

typedef TBdispFillArea* TBdisplayFillAreaRef;

typedef enum {
    ColorModeDisableFullColor     = 0,
    ColorModeEnableFullColor      = 1
} TColorMode;

typedef enum {
    FrameModeSetToWhite     = 0,
    FrameModeSetToColor     = 1
} TFrameMode;


void Bdisp_AreaClr(TBdispFillArea *area, uint8_t target, color_t color);


/**
 @brief Switches the screen between full color mode (16 bits per pixel, RGB565) and indexed color mode (3 bits per pixel, 8 colors - the same that can be used with PrintXY).
 @param full 0 to disable full color, 1 to enable full color.
 @return The result of Bdisp_IsZeroDDRegisterB (see disassembly for details).
 */
int Bdisp_EnableColor(int full);

//MARK: - Frame Control

/**
 @brief Directly changes the color of the screen border, does not involve VRAM (so Bdisp_PutDisp_DD need not follow). See Display for more information.
 
 @param  color  The color to draw the border with.
 */
void DrawFrame(color_t color);


/**
 @brief Sets the word at 0xFD801460, which controls the system-wide frame color.
 
 @param mode If 0, the word at 0xFD801460 is set to 0xFFFF. If 1, the word at 0xFD801460 is set to color.
 @param color The color to which the frame is set when mode is 1.
 
 @return The value of word at 0xFD801460.
*/
color_t FrameColor(TFrameMode mode, color_t color);

void DrawFrameWorkbench(int, int, int, int, int);

//MARK: - VRAM General Display Manipulating SYSCALLS

/**
 - Returns Return a pointer to the system's video memory.
 */
void * GetVRAMAddress(void);

/**
 - Returns Return a pointer to the memory used by SaveVRAM_1 and LoadVRAM_1.
 */
void * GetSecondaryVRAMAddress(void);

void Bdisp_AllClr_VRAM(void);
void Bdisp_SetPoint_VRAM(int x, int y, int color);
void Bdisp_SetPointWB_VRAM(int x, int y, int color);
uint16_t Bdisp_GetPoint_VRAM(int x, int y);
void SaveVRAM_1(void);
void LoadVRAM_1(void);
void Bdisp_Fill_VRAM(int color, int mode);

//MARK: - DD Display Manipulating SYSCALLS
void Bdisp_AreaClr_DD_x3(void*p1);
void Bdisp_DDRegisterSelect(int registerno);
void Bdisp_PutDisp_DD(void);
void Bdisp_PutDisp_DD_stripe(int y1, int y2);
void Bdisp_SetPoint_DD(int x, int y, int color);
uint16_t Bdisp_GetPoint_DD_Workbench(int x, int y);
uint16_t Bdisp_GetPoint_DD(int x, int y);
void DirectDrawRectangle(int x1, int y1, int x2, int y2, color_t color);
void HourGlass(void);
void Bdisp_DefineDMARange(int x1, int x2, int y1, int y2);
uint16_t Bdisp_WriteDDRegister3_bit7(int value);

//MARK: - Graphic Writing
struct TBdispGraph {
    int x;
    int y;
    int xOffset;
    int yOffset;
    int width;
    int height;
    char colorMode;
    char zero4;
    char P20_1;
    char P20_2;
    int bitmap;
    char colorIndex1;
    char colorIndex2;
    char colorIndex3;
    char P20_3;
    char writeModify;
    char writeKind;
    char zero6;
    char one1;
    int transparency;
};

void Bdisp_WriteGraphVRAM(struct TBdispGraph * gd);
void Bdisp_WriteGraphDD_WB(struct TBdispGraph * gd);

//MARK: - Shape Drawing

typedef struct TBdispShape {
    int dx;
    int dy;
    int wx;
    int wy;
    int color;
    TBdispFillArea saved;
} TBdispShape;

typedef TBdispShape* TBdispShapeRef;

void Bdisp_ShapeBase3XVRAM(void*shape);
void Bdisp_ShapeBase(uint8_t * work, TBdispShapeRef shape, int color, int line_width, int zero1, int zero2);
void Bdisp_ShapeToVRAM16C(void*, int color);
void Bdisp_ShapeToDD(void*shape, int color);

// The following rectangle-related syscalls draw a rectangle to VRAM, x between 0 and 383 (inclusive), y between 0 and 191 (inclusive).
// These add 24 pixels automatically, avoiding the status area:

/// Draws a rectangle to VRAM using a TEXT_COLOR.
void Bdisp_Rectangle(int x1, int y1, int x2, int y2, char color);

/// Draws a filled rectangle to VRAM using a TEXT_COLOR
void Bdisp_FilledRectangle(int x1, int y1, int x2, int y2, char color);

/// Draws a filled rectangle to VRAM using a color_t
void Bdisp_FilledRectangleFullColor(int x1, int y1, int x2, int y2, uint16_t color);


//MARK: - Background-Related SYSCALLS
void SetBackGround(int);
void WriteBackground(void*target, int width, int height, void*source, int, int, int);

//MARK: - Message Boxes, Error Messages, Dialogs...
void Box(int, int, int, int, int);
void BoxInnerClear(int);
void Box2(int, int);
void BoxYLimits(int lines, int*top, int*bottom);
void AUX_DisplayErrorMessage(int msgno);
void MsgBoxPush(int lines);
void MsgBoxPop(void);
void DisplayMessageBox(uint8_t*message);
short CharacterSelectDialog(void);
uint8_t ColorIndexDialog1(uint8_t initial_index, uint16_t disable_mask);
void MsgBoxMoveWB(void*buffer, int x0, int y0, int x1, int y1, int direction); //it's more general purpose, works not only for MsgBoxes but for any VRAM contents.

//MARK: - Cursor Manipulation SYSCALLS

/**
 Sets the cursor position for Print_OS

 - Parameter x: Must be in range of [1,21]
 - Parameter y: Must be in range of [1,8]
*/
void locate_OS(int x, int y);

void Cursor_SetFlashOn(uint8_t cursorType);
void Cursor_SetFlashOff(void);
int SetCursorFlashToggle(int);
void Keyboard_CursorFlash(void);

//MARK: - Character Printing SYSCALLS

/*!
 The index color for black, blue, green, cyan, red, magenta, yellow and white.
 @enum            TTextColor
 
 @constant        TTextColorBlack
 
 @discussion      These colors are index colors, NOT! 565 RGB color values.
 */
typedef enum {
    TextColorBlack   = 0b000,
    TextColorBlue    = 0b001,
    TextColorGreen   = 0b010,
    TextColorCyan    = 0b011,
    TextColorRed     = 0b100,
    TextColorMagenta = 0b101,
    TextColorYellow  = 0b110,
    TextColorWhite   = 0b111
} TTextColor;

typedef enum {
    TextModeNormal   = 0x00,
    TextModeInvert   = 0x01,
    TextModeTransparentBackground   = 0x20
} TTextMode;


void PrintLine(const char *msg, int imax);
void PrintLine2(int, int, const char *, int, int, int, int, int);
void PrintXY_2(int mode, int x, int y, int msgno, int color);
void PrintXY(int x, int y, const char *string, int mode, int color);
void PrintCXY(int, int, const char *, int, int, int, int, int, int);
void PrintGlyph(int, int, uint8_t * glyph, int, color_t color, color_t bgcolor, int);
void *GetMiniGlyphPtr(uint16_t mb_glyph_no, uint16_t*glyph_info);
void PrintMiniGlyph(int x, int y, void*glyph, uint32_t mode, int glyph_width, int, int, int, int, int color, int bgcolor, int);
void PrintMini(int *x, int *y, const char *MB_string, uint32_t mode_flags, uint32_t xlimit, int, int, int color, int bgcolor, int writeflag, int P11);
void PrintMiniMini(int *x, int *y, const char *MB_string, int mode1, int color, int mode2);
void Print_OS(const char*msg, int mode, int zero2);
void Bdisp_WriteSystemMessage(int x, int y, int msgno, int mode, char color3);
void Bdisp_MMPrintRef(int*x, int*y, uint8_t*, int mode, int xmax, int, int, int color, int, int, int);
void Bdisp_MMPrint(int x, int y, char*, int mode, int xmax, int, int, int color, int backcolor, int, int);

//MARK: - Progressbars and Scrollbars
typedef struct TScrollbar
{
  uint32_t _unknown_1; // unknown changes indicator height, set to 0
  uint32_t indicatorMaximum; // max logical indicator range
  uint32_t indicatorHeight; // height of the indicator in units
  uint32_t indicatorPosition; // indicator position in units of max
  uint32_t _unknown_5; // unknown, set to 0
  uint16_t barLeft; // x position of bar
  uint16_t barTop; // y position of bar
  uint16_t barHeight; // height of bar
  uint16_t barWidth; // width of bar
} TScrollbar ;

void Scrollbar(TScrollbar * scrollbar);
void StandardScrollbar(void*);
void ProgressBar(int, int);
void ProgressBar0(int, int, int, int current, int max);
void ProgressBar2(uint8_t *heading, int current, int max);

//MARK: - Status Area or Header Related SYSCALLS

typedef enum DefineStatusArea {
    kDefineStatusArea_Clear       = 0,
    kDefineStatusArea_SetDefault  = 1
} DefineStatusArea;

typedef enum {
    StatusAreaBattery            = 0x001,
    StatusAreaAlphaShift         = 0x002,
    StatusAreaSetupInputOutput   = 0x004,
    StatusAreaSetupFracResult    = 0x008,
    StatusAreaSetupAngle         = 0x010,
    StatusAreaSetupComplexMode   = 0x020,
    StatusAreaSetupDisplay       = 0x040,
    StatusAreaText               = 0x080,
    StatusAreaGlyph              = 0x100
} TStatusArea;

typedef struct TGlyphDefine {
    short    dx;    // usually 0x24, width of the glyph
    short    dy;    // usually 0x16, height of the glyph
    void*    bitmap; // 2-byte-per-pixel (RGB565) bitmap
    short    xAlignment; // alignment of the glyph in the status bar, see below.
    short    xOffset; // offset of the glyph, meaning varies with xAlignment.
} TGlyphDefine;

typedef TGlyphDefine* TGlyphDefineRef;

int DefineStatusAreaFlags(int mode, int flags, char* color, char* bgcolor);

/**
 Defines a custom glyph to be shown on the status area.
 
 - Parameter index: Index of the glyph in the array.
 - Parameter glypth: Pointer to a struct containing information on the glyph to display
 */
void DefineStatusGlyph(int index, TGlyphDefineRef glypth);

void DefineStatusMessage(char*msg, short, char, char);
void DisplayStatusArea(void);
void DrawHeaderLine(void);
void EnableStatusArea(int);
void Bdisp_HeaderFill(uint8_t color_idx1, uint8_t color_idx2);
void Bdisp_HeaderFill2(uint32_t, uint32_t, uint8_t, uint8_t);
void Bdisp_HeaderText(void);
void Bdisp_HeaderText2(void);
void EnableDisplayHeader(int, int);

//MARK: - Status Area Icon SYSCALLS
//NOTE: Status area icon syscalls: (it may be more appropriate to use the status area flags)

void APP_EACT_StatusIcon(int); //not sure what this is exactly for, if it displays something on screen it's here, otherwise in app.h. will test some day (gbl08ma)
void SetupMode_StatusIcon(void); //not sure what this does, doesn't seem to be documented anywhere. will test some day (gbl08ma)
void d_c_Icon(uint32_t);
void BatteryIcon(uint32_t);
void KeyboardIcon(uint32_t);
void LineIcon(uint32_t);
void NormIcon(uint32_t);
void RadIcon(uint32_t);
void RealIcon(uint32_t);

//Other:
void FKey_Display(int, void*);
void GetFKeyPtr(int, void*);
void DispInt(int, int); //not sure what this does, doesn't seem to be documented anywhere. will test some day (gbl08ma)
int LocalizeMessage1(int msgno, char*result);
int SMEM_MapIconToExt(uint8_t*filename, uint16_t*foldername, uint32_t*msgno, uint16_t*iconbuffer); // despite starting with SMEM, this is mostly a graphical function used to get icons for different file types.

//MARK: - NOT! SYSCALLS (defined within libfxcg)


#ifdef __cplusplus
}
#endif

#endif /* __FXCG_DISPLAY_H */
