/* Generated automatically. */
static const char configuration_arguments[] = "../gcc/./configure --target=sh3eb-elf --prefix=/Applications/PrizmSDK --disable-nls --enable-languages=c,c++ --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
