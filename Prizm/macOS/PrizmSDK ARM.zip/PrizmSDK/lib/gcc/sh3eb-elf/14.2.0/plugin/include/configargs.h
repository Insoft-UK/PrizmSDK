/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-14.2.0/configure --target=sh3eb-elf --prefix=/Users/richie/Downloads/libfxcg/PrizmSDK --disable-nls --enable-languages=c,c++ --disable-multilib --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
