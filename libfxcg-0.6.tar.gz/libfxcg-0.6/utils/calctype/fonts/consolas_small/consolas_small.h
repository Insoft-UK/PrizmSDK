/* Generated font file for CalcType (Prizm) */
#pragma once

#include "../../calctype.h"

extern const CalcTypeFont consolas_small;

