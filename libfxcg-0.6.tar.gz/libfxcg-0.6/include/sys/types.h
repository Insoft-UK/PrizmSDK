#ifndef _FXCG_SYS_TYPES_H
#define _FXCG_SYS_TYPES_H

typedef unsigned off_t;

#endif
